package sample.spring.yse;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IBookDAO {
	// 책 생성
	public int insert(BookVO book);
	// 책 상세
	public Map<String, Object> detail(Map<String, Object> map);
	// 책 조회
	public List<BookVO> list();
	// 책 수정
	public int update(BookVO book);
	// 책 삭제
	public int delete(BookVO book);
}
