package sample.spring.yse;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

	@Autowired
	IBookDAO dao;

	// 책 생성
	public void insert(BookVO book) throws Exception {
		int result = dao.insert(book);
		System.out.println(result);
		if (result == 0) {
			throw new Exception();
		}
	}

	// 책 상세
	public Map<String, Object> getBookDetail(Map<String, Object> paraMap) throws Exception {
		try {
			// DAO를 통해 책 상세 정보를 가져옴.
			Map<String, Object> detailMap = dao.detail(paraMap);
			return detailMap;
		} catch (Exception e) {
			// 예외처리
			throw new Exception("책 상세 오류", e);
		}
	}
	// 책 조회
	public List<BookVO> list(){
		List<BookVO> result = dao.list();
		return result;
	}
	// 책 수정
	public void BookUpdate(BookVO book) throws Exception {
		int result = dao.update(book);
		if(result == 0) {
			throw new Exception();
		}
	}
	// 책 삭제
	public void Bookdelete(BookVO book) throws Exception{
		int result = dao.delete(book);
		if(result == 0) {
			throw new Exception();
		}
	}
}
