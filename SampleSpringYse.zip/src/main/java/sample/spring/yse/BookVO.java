package sample.spring.yse;

public class BookVO {
	private String bookId;		/**책 아이디*/
	private String title;		/**책 제목*/
	private String category;	/**책 카테고리*/
	private String price;		/**책 가격*/
	private String insertDate;	/**책 생성날짜*/
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
	@Override
	public String toString() {
		return "BookVO [bookId=" + bookId + ", title=" + title + ", category=" + category + ", price=" + price
				+ ", insertDate=" + insertDate + "]";
	}
	public BookVO(String bookId, String title, String category, String price, String insertDate) {
		this.bookId = bookId;
		this.title = title;
		this.category = category;
		this.price = price;
		this.insertDate = insertDate;
	}
	public BookVO() {
		
	}
	
	
	
}
