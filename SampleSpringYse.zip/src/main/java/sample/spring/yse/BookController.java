package sample.spring.yse;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BookController {

	@Autowired
	BookService bookService;

	// book 생성 화면
	@RequestMapping("/create")
	public String registView() {
		System.out.println("Hi");
		return "book/create";
	}
	// book 생성 기능
	@RequestMapping("/insertDo")
	public String insertDo(HttpServletRequest request) {
		String bookId = request.getParameter("bookid");
		String title = request.getParameter("title");
		String category = request.getParameter("category");
		String price = request.getParameter("price");
		String insertDate = request.getParameter("date");
		BookVO book = new BookVO(bookId, title, category, price, insertDate);
		try {
			bookService.insert(book);
		} catch (Exception e) {
			e.printStackTrace();
			return "errorView";
		}
		return "redirect:/list";
	}
	// book 상세
	@RequestMapping("/detail")
	public ModelAndView detail(@RequestParam Map<String, Object> map) throws Exception {
		Map<String, Object> detailMap = this.bookService.getBookDetail(map);
		System.out.println("getBookDetail result: " + detailMap);
		ModelAndView mav = new ModelAndView("book/detail");
		String bookId = map.get("bookId") != null ? map.get("bookId").toString():"";
		mav.addObject("data", detailMap);
		mav.addObject("bookId", bookId);
		System.out.println("mav result: " + mav);
		System.out.println("bookId result: " + bookId);
		return mav;
	}
	// book 리스트
	@RequestMapping("/list")
	public String bookList(Model model ) {
		List<BookVO> bookList = bookService.list();
		model.addAttribute("bookList", bookList);
		System.out.println(bookList);
		return "book/list";
	}
	// 수정 화면
	@RequestMapping("/update")
	public ModelAndView update(@RequestParam Map<String, Object> map) throws Exception {
		Map<String, Object> detailMap = this.bookService.getBookDetail(map);
		ModelAndView mav = new ModelAndView("book/update");
		String bookId = map.get("bookId") != null ? map.get("bookId").toString():"";
		mav.addObject("data", detailMap);
		mav.addObject("bookId", bookId);
		System.out.println("업데이트: " + mav);
		return mav;
	}
	// book 수정
	@PostMapping("/updateDo")
	public String bookUpdate(BookVO book)throws Exception{
		bookService.BookUpdate(book);
		
		return "redirect:/list";
	}
	// book 삭제
	@PostMapping("/deleteDo")
	public String bookDelete(BookVO book)throws Exception{
		bookService.Bookdelete(book);
		return "redirect:/list";
	}
}
